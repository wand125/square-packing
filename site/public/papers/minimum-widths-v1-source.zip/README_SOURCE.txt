Minimum Widths for Unit Squares in Thin Rectangles

The website paper is the primary presentation. This archive contains the
matching English TeX source, two vector figure PDFs, and the English and
Japanese Markdown texts.

To typeset the English companion, unpack while preserving directories and run:

  xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error minimum_widths.tex
  xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error minimum_widths.tex

The TeX file includes its preamble. The figures/ directory is required.
The retained build used XeLaTeX from TeX Live 2020. Diagram coordinates and
plots illustrate manuscript formulas; they are not proof certificates.
These commands render a document and do not execute mathematical checkers.

日本語本文は要約ではなく、英語本文全節に対応する全文訳です。
図のPDFはTeXと同じ相対位置に置いてください。数学的な検証記録と
再実行の条件については論文第6節を参照してください。
