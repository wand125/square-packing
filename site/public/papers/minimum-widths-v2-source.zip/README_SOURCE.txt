Minimum Widths for Unit Squares in Thin Rectangles

This is the public article-source bundle: English TeX, English and Japanese
Markdown texts, and the two vector figure PDFs. The online paper also provides
an interactive illustration. Rendering and its decimal values are numerical
illustrations, not mathematical verification.

The TeX source uses XeLaTeX. Keep its figures directory beside the TeX file.
This bundle does not include the complete mathematical verification-code and
input-data archive. See Section 6.3 and Appendix A for its current status and
the obligations a complete archive must satisfy.

This working paper is computer-assisted and has not been externally peer
reviewed. 